from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.db.models import Sum, Q
from decimal import Decimal
from .models import Medicine, Supplier, Customer, Sale, SaleItem, Category
from .forms import LoginForm, MedicineForm, SupplierForm, CustomerForm


# ── Authentication ─────────────────────────────────────────

def home(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return redirect('login')

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            messages.success(request, f"Welcome, {user.username}!")
            return redirect('dashboard')
        else:
            messages.error(request, "Invalid username or password!")
    return render(request, 'pharmacy/login.html', {})

def logout_view(request):
    logout(request)
    return redirect('login')


# ── Dashboard ──────────────────────────────────────────────

@login_required
def dashboard(request):
    today = timezone.now().date()
    todays_sales = Sale.objects.filter(
        sale_date__date=today
    ).aggregate(total=Sum('total_amount'))['total'] or 0

    context = {
        'total_medicines': Medicine.objects.count(),
        'todays_sales': todays_sales,
        'low_stock_count': Medicine.objects.filter(quantity__lte=10).count(),
        'expiring_soon_count': Medicine.objects.filter(
            expiry_date__lte=today + timezone.timedelta(days=30),
            expiry_date__gte=today
        ).count(),
        'low_stock_medicines': Medicine.objects.filter(quantity__lte=10)[:5],
        'recent_sales': Sale.objects.select_related(
            'customer', 'pharmacist'
        ).order_by('-sale_date')[:10],
    }
    return render(request, 'pharmacy/dashboard.html', context)


# ── Medicine ───────────────────────────────────────────────

@login_required
def medicine_list(request):
    q = request.GET.get('q', '')
    medicines = Medicine.objects.select_related('category', 'supplier').order_by('name')
    if q:
        medicines = medicines.filter(
            Q(name__icontains=q) | Q(category__name__icontains=q)
        )
    return render(request, 'pharmacy/medicine_list.html', {'medicines': medicines})

@login_required
def medicine_add(request):
    form = MedicineForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Medicine added successfully!")
        return redirect('medicine_list')
    return render(request, 'pharmacy/medicine_form.html',
                  {'form': form, 'title': 'Add Medicine'})

@login_required
def medicine_edit(request, pk):
    medicine = get_object_or_404(Medicine, pk=pk)
    form = MedicineForm(request.POST or None, instance=medicine)
    if form.is_valid():
        form.save()
        messages.success(request, "Medicine updated!")
        return redirect('medicine_list')
    return render(request, 'pharmacy/medicine_form.html',
                  {'form': form, 'title': 'Edit Medicine'})

@login_required
def medicine_delete(request, pk):
    medicine = get_object_or_404(Medicine, pk=pk)
    name = medicine.name
    medicine.delete()
    messages.warning(request, f"'{name}' deleted.")
    return redirect('medicine_list')


# ── Supplier ───────────────────────────────────────────────

@login_required
def supplier_list(request):
    suppliers = Supplier.objects.all().order_by('name')
    return render(request, 'pharmacy/supplier_list.html', {'suppliers': suppliers})

@login_required
def supplier_add(request):
    form = SupplierForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Supplier added!")
        return redirect('supplier_list')
    return render(request, 'pharmacy/supplier_form.html',
                  {'form': form, 'title': 'Add Supplier'})


# ── Customer ───────────────────────────────────────────────

@login_required
def customer_list(request):
    customers = Customer.objects.all().order_by('name')
    return render(request, 'pharmacy/customer_list.html', {'customers': customers})

@login_required
def customer_add(request):
    form = SupplierForm(request.POST or None)
    form = CustomerForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Customer added!")
        return redirect('customer_list')
    return render(request, 'pharmacy/customer_form.html',
                  {'form': form, 'title': 'Add Customer'})


# ── Billing ────────────────────────────────────────────────

@login_required
def billing(request):
    medicines = Medicine.objects.filter(quantity__gt=0).order_by('name')
    customers = Customer.objects.all().order_by('name')

    if request.method == 'POST':
        customer_id = request.POST.get('customer')
        medicine_ids = request.POST.getlist('medicine')
        quantities = request.POST.getlist('quantity')
        gst = Decimal(request.POST.get('gst', '18'))

        if not medicine_ids:
            messages.error(request, "Please add at least one medicine.")
            return render(request, 'pharmacy/billing.html',
                         {'medicines': medicines, 'customers': customers})

        sale = Sale.objects.create(
            customer_id=customer_id if customer_id else None,
            pharmacist=request.user,
            gst_percent=gst,
        )

        subtotal = Decimal('0')
        for med_id, qty in zip(medicine_ids, quantities):
            med = Medicine.objects.get(pk=med_id)
            qty = int(qty)
            if qty > med.quantity:
                messages.error(request, f"Insufficient stock for {med.name}!")
                sale.delete()
                return render(request, 'pharmacy/billing.html',
                             {'medicines': medicines, 'customers': customers})

            SaleItem.objects.create(
                sale=sale,
                medicine=med,
                quantity=qty,
                unit_price=med.price,
            )
            subtotal += med.price * qty
            med.quantity -= qty
            med.save()

        gst_amount = (subtotal * gst) / 100
        total = subtotal + gst_amount
        sale.subtotal = subtotal
        sale.gst_amount = gst_amount
        sale.total_amount = total
        sale.save()

        messages.success(request, f"Sale saved! Invoice #{sale.id}")
        return redirect('invoice', sale_id=sale.id)

    return render(request, 'pharmacy/billing.html', {
        'medicines': medicines,
        'customers': customers,
    })

@login_required
def sale_list(request):
    sales = Sale.objects.select_related(
        'customer', 'pharmacist'
    ).order_by('-sale_date')
    return render(request, 'pharmacy/sale_list.html', {'sales': sales})

@login_required
def invoice(request, sale_id):
    sale = get_object_or_404(Sale, pk=sale_id)
    items = sale.items.select_related('medicine')
    return render(request, 'pharmacy/invoice.html', {'sale': sale, 'items': items})

@login_required
def invoice_pdf(request, sale_id):
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import A4
    from django.http import HttpResponse

    sale = get_object_or_404(Sale, pk=sale_id)
    items = sale.items.select_related('medicine')

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'filename="invoice_{sale.id}.pdf"'

    p = canvas.Canvas(response, pagesize=A4)
    width, height = A4

    p.setFont("Helvetica-Bold", 20)
    p.drawString(50, height - 60, "PharmaCare")
    p.setFont("Helvetica", 12)
    p.drawString(50, height - 80, "Tax Invoice")
    p.drawString(400, height - 60, f"Invoice #: {sale.id}")
    p.drawString(400, height - 80, f"Date: {sale.sale_date.strftime('%d/%m/%Y')}")

    p.setFont("Helvetica-Bold", 11)
    p.drawString(50, height - 120, "Bill To:")
    p.setFont("Helvetica", 11)
    customer_name = sale.customer.name if sale.customer else "Walk-in Customer"
    p.drawString(50, height - 140, customer_name)

    y = height - 180
    p.setFont("Helvetica-Bold", 10)
    p.drawString(50, y, "Medicine")
    p.drawString(280, y, "Qty")
    p.drawString(350, y, "Unit Price")
    p.drawString(450, y, "Total")
    p.line(50, y - 5, 550, y - 5)

    p.setFont("Helvetica", 10)
    y -= 25
    for item in items:
        p.drawString(50, y, item.medicine.name[:30])
        p.drawString(280, y, str(item.quantity))
        p.drawString(350, y, f"Rs. {item.unit_price}")
        p.drawString(450, y, f"Rs. {item.total_price}")
        y -= 20

    p.line(50, y, 550, y)
    y -= 20
    p.drawString(350, y, "Subtotal:")
    p.drawString(450, y, f"Rs. {sale.subtotal}")
    y -= 18
    p.drawString(350, y, f"GST ({sale.gst_percent}%):")
    p.drawString(450, y, f"Rs. {sale.gst_amount}")
    y -= 18
    p.setFont("Helvetica-Bold", 11)
    p.drawString(350, y, "TOTAL:")
    p.drawString(450, y, f"Rs. {sale.total_amount}")

    p.showPage()
    p.save()
    return response
from django.contrib.auth.models import User
from django.contrib.auth import update_session_auth_hash

def signup_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        if password1 != password2:
            messages.error(request, "Passwords don't match!")
            return render(request, 'pharmacy/signup.html')
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken!")
            return render(request, 'pharmacy/signup.html')
        user = User.objects.create_user(
            username=username, email=email, password=password1)
        login(request, user)
        messages.success(request, f"Welcome {username}!")
        return redirect('dashboard')
    return render(request, 'pharmacy/signup.html')


@login_required
def change_password_view(request):
    if request.method == 'POST':
        old_password = request.POST.get('old_password')
        new_password1 = request.POST.get('new_password1')
        new_password2 = request.POST.get('new_password2')
        if not request.user.check_password(old_password):
            messages.error(request, "Old password is incorrect!")
            return render(request, 'pharmacy/change_password.html')
        if new_password1 != new_password2:
            messages.error(request, "New passwords don't match!")
            return render(request, 'pharmacy/change_password.html')
        request.user.set_password(new_password1)
        request.user.save()
        update_session_auth_hash(request, request.user)
        messages.success(request, "Password changed successfully!")
        return redirect('dashboard')
    return render(request, 'pharmacy/change_password.html')


def forgot_password_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        new_password1 = request.POST.get('new_password1')
        new_password2 = request.POST.get('new_password2')
        try:
            user = User.objects.get(username=username)
            if new_password1 != new_password2:
                messages.error(request, "Passwords don't match!")
                return render(request, 'pharmacy/forgot_password.html')
            user.set_password(new_password1)
            user.save()
            messages.success(request, "Password reset successfully! Please login.")
            return redirect('login')
        except User.DoesNotExist:
            messages.error(request, "Username not found!")
    return render(request, 'pharmacy/forgot_password.html')
def signup_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        if password1 != password2:
            messages.error(request, "Passwords don't match!")
            return render(request, 'pharmacy/signup.html')
        from django.contrib.auth.models import User
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken!")
            return render(request, 'pharmacy/signup.html')
        user = User.objects.create_user(
            username=username, email=email, password=password1)
        login(request, user)
        messages.success(request, f"Welcome {username}!")
        return redirect('dashboard')
    return render(request, 'pharmacy/signup.html')


@login_required
def change_password(request):
    if request.method == 'POST':
        old_password = request.POST.get('old_password')
        new_password1 = request.POST.get('new_password1')
        new_password2 = request.POST.get('new_password2')
        if not request.user.check_password(old_password):
            messages.error(request, "Old password is incorrect!")
            return render(request, 'pharmacy/change_password.html')
        if new_password1 != new_password2:
            messages.error(request, "Passwords don't match!")
            return render(request, 'pharmacy/change_password.html')
        request.user.set_password(new_password1)
        request.user.save()
        messages.success(request, "Password changed!")
        return redirect('login')
    return render(request, 'pharmacy/change_password.html')


def forgot_password(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        new_password = request.POST.get('new_password')
        from django.contrib.auth.models import User
        try:
            user = User.objects.get(username=username)
            user.set_password(new_password)
            user.save()
            messages.success(request, "Password reset! Please login.")
            return redirect('login')
        except User.DoesNotExist:
            messages.error(request, "Username not found!")
    return render(request, 'pharmacy/forgot_password.html')